from .base_provider import ProviderType

logging: bool = False
version_check: bool = True
last_provider: ProviderType = None